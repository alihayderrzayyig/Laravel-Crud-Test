<?php $__env->startSection('content'); ?>
<h1 class="page-header text-center">Laravel Crud Operation</h1>
<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<h2>Members Table
			<button type="button" data-target="#addnew" data-toggle="modal" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Member</button>
		</h2>
	</div>
</div>
<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<table class="table table-bordered table-responsive table-striped">
			<thead>
				<th>Fisrtname</th>
				<th>Lastname</th>
				<th>Action</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($member->firstname); ?></td>
						<td><?php echo e($member->lastname); ?></td>
						<td><a href="#edit<?php echo e($member->id); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> <a href="#delete<?php echo e($member->id); ?>" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</a>
							<?php echo $__env->make('action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>